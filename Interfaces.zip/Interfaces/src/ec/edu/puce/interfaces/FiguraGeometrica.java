package ec.edu.puce.interfaces;

public interface FiguraGeometrica {
	
	abstract public double calcularArea();

}
